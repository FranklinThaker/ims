--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 10.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."RequestComponents" DROP CONSTRAINT "RequestComponents_userId_fkey";
ALTER TABLE ONLY public."RequestComponents" DROP CONSTRAINT "RequestComponents_componentId_fkey";
ALTER TABLE ONLY public."RequestComponents" DROP CONSTRAINT "RequestComponents_categoryId_fkey";
ALTER TABLE ONLY public."Invoices" DROP CONSTRAINT "Invoices_invoicerId_fkey";
ALTER TABLE ONLY public."Incidents" DROP CONSTRAINT "Incidents_resolvedBy_fkey";
ALTER TABLE ONLY public."Incidents" DROP CONSTRAINT "Incidents_incidentBy_fkey";
ALTER TABLE ONLY public."IncidentUpdates" DROP CONSTRAINT "IncidentUpdates_updateBy_fkey";
ALTER TABLE ONLY public."IncidentUpdates" DROP CONSTRAINT "IncidentUpdates_incidentId_fkey";
ALTER TABLE ONLY public."Components" DROP CONSTRAINT "Components_categoryId_fkey";
ALTER TABLE ONLY public."Components" DROP CONSTRAINT "Components_assignedTo_fkey";
ALTER TABLE ONLY public."Components" DROP CONSTRAINT "Components_assignedBy_fkey";
ALTER TABLE ONLY public."Users" DROP CONSTRAINT "Users_pkey";
ALTER TABLE ONLY public."SequelizeMeta" DROP CONSTRAINT "SequelizeMeta_pkey";
ALTER TABLE ONLY public."RequestComponents" DROP CONSTRAINT "RequestComponents_pkey";
ALTER TABLE ONLY public."Invoices" DROP CONSTRAINT "Invoices_pkey";
ALTER TABLE ONLY public."Invoicers" DROP CONSTRAINT "Invoicers_pkey";
ALTER TABLE ONLY public."Incidents" DROP CONSTRAINT "Incidents_pkey";
ALTER TABLE ONLY public."IncidentUpdates" DROP CONSTRAINT "IncidentUpdates_pkey";
ALTER TABLE ONLY public."Components" DROP CONSTRAINT "Components_pkey";
ALTER TABLE ONLY public."Categories" DROP CONSTRAINT "Categories_pkey";
ALTER TABLE public."Users" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."RequestComponents" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Invoices" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Invoicers" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Incidents" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."IncidentUpdates" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Components" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Categories" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public."Users_id_seq";
DROP TABLE public."Users";
DROP TABLE public."SequelizeMeta";
DROP SEQUENCE public."RequestComponents_id_seq";
DROP TABLE public."RequestComponents";
DROP SEQUENCE public."Invoices_id_seq";
DROP TABLE public."Invoices";
DROP SEQUENCE public."Invoicers_id_seq";
DROP TABLE public."Invoicers";
DROP SEQUENCE public."Incidents_id_seq";
DROP TABLE public."Incidents";
DROP SEQUENCE public."IncidentUpdates_id_seq";
DROP TABLE public."IncidentUpdates";
DROP SEQUENCE public."Components_id_seq";
DROP TABLE public."Components";
DROP SEQUENCE public."Categories_id_seq";
DROP TABLE public."Categories";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Categories" (
    id integer NOT NULL,
    "categoryType" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Categories" OWNER TO postgres;

--
-- Name: Categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Categories_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Categories_id_seq" OWNER TO postgres;

--
-- Name: Categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Categories_id_seq" OWNED BY public."Categories".id;


--
-- Name: Components; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Components" (
    id integer NOT NULL,
    "categoryId" integer NOT NULL,
    "componentName" character varying(255) NOT NULL,
    status boolean NOT NULL,
    "serialNo" character varying(255),
    "warrantyDate" timestamp with time zone,
    "assignedTo" integer,
    "assignedBy" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Components" OWNER TO postgres;

--
-- Name: Components_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Components_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Components_id_seq" OWNER TO postgres;

--
-- Name: Components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Components_id_seq" OWNED BY public."Components".id;


--
-- Name: IncidentUpdates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."IncidentUpdates" (
    id integer NOT NULL,
    "incidentId" integer NOT NULL,
    "updateBy" integer NOT NULL,
    updates character varying(255),
    status character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."IncidentUpdates" OWNER TO postgres;

--
-- Name: IncidentUpdates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."IncidentUpdates_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."IncidentUpdates_id_seq" OWNER TO postgres;

--
-- Name: IncidentUpdates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."IncidentUpdates_id_seq" OWNED BY public."IncidentUpdates".id;


--
-- Name: Incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Incidents" (
    id integer NOT NULL,
    "incidentBy" integer NOT NULL,
    "incidentName" character varying(255) NOT NULL,
    incident text NOT NULL,
    updates character varying(255),
    "resolvedBy" integer,
    status character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Incidents" OWNER TO postgres;

--
-- Name: Incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Incidents_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Incidents_id_seq" OWNER TO postgres;

--
-- Name: Incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Incidents_id_seq" OWNED BY public."Incidents".id;


--
-- Name: Invoicers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Invoicers" (
    id integer NOT NULL,
    "invoicerName" character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Invoicers" OWNER TO postgres;

--
-- Name: Invoicers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Invoicers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Invoicers_id_seq" OWNER TO postgres;

--
-- Name: Invoicers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Invoicers_id_seq" OWNED BY public."Invoicers".id;


--
-- Name: Invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Invoices" (
    id integer NOT NULL,
    "invoicerId" integer NOT NULL,
    "invoiceSerial" character varying(255) NOT NULL,
    "itemName" character varying(255) NOT NULL,
    quantity numeric(3,0) NOT NULL,
    rate numeric(6,0) NOT NULL,
    amount numeric(7,0) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Invoices" OWNER TO postgres;

--
-- Name: Invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Invoices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Invoices_id_seq" OWNER TO postgres;

--
-- Name: Invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Invoices_id_seq" OWNED BY public."Invoices".id;


--
-- Name: RequestComponents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RequestComponents" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "categoryId" integer NOT NULL,
    "componentId" integer NOT NULL,
    "componentName" character varying(255) NOT NULL,
    issue character varying(255) NOT NULL,
    status character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."RequestComponents" OWNER TO postgres;

--
-- Name: RequestComponents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RequestComponents_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RequestComponents_id_seq" OWNER TO postgres;

--
-- Name: RequestComponents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RequestComponents_id_seq" OWNED BY public."RequestComponents".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO postgres;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    "firstName" character varying(255) NOT NULL,
    "lastName" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "contactNo" numeric(10,0) NOT NULL,
    role boolean NOT NULL,
    status boolean NOT NULL,
    "passwordResetToken" character varying(255),
    "passwordResetExpires" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: Categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categories" ALTER COLUMN id SET DEFAULT nextval('public."Categories_id_seq"'::regclass);


--
-- Name: Components id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Components" ALTER COLUMN id SET DEFAULT nextval('public."Components_id_seq"'::regclass);


--
-- Name: IncidentUpdates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IncidentUpdates" ALTER COLUMN id SET DEFAULT nextval('public."IncidentUpdates_id_seq"'::regclass);


--
-- Name: Incidents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Incidents" ALTER COLUMN id SET DEFAULT nextval('public."Incidents_id_seq"'::regclass);


--
-- Name: Invoicers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoicers" ALTER COLUMN id SET DEFAULT nextval('public."Invoicers_id_seq"'::regclass);


--
-- Name: Invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoices" ALTER COLUMN id SET DEFAULT nextval('public."Invoices_id_seq"'::regclass);


--
-- Name: RequestComponents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestComponents" ALTER COLUMN id SET DEFAULT nextval('public."RequestComponents_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Data for Name: Categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categories" (id, "categoryType", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Categories" (id, "categoryType", "createdAt", "updatedAt") FROM '$$PATH$$/2921.dat';

--
-- Data for Name: Components; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Components" (id, "categoryId", "componentName", status, "serialNo", "warrantyDate", "assignedTo", "assignedBy", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Components" (id, "categoryId", "componentName", status, "serialNo", "warrantyDate", "assignedTo", "assignedBy", "createdAt", "updatedAt") FROM '$$PATH$$/2923.dat';

--
-- Data for Name: IncidentUpdates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."IncidentUpdates" (id, "incidentId", "updateBy", updates, status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."IncidentUpdates" (id, "incidentId", "updateBy", updates, status, "createdAt", "updatedAt") FROM '$$PATH$$/2931.dat';

--
-- Data for Name: Incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Incidents" (id, "incidentBy", "incidentName", incident, updates, "resolvedBy", status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Incidents" (id, "incidentBy", "incidentName", incident, updates, "resolvedBy", status, "createdAt", "updatedAt") FROM '$$PATH$$/2929.dat';

--
-- Data for Name: Invoicers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Invoicers" (id, "invoicerName", status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Invoicers" (id, "invoicerName", status, "createdAt", "updatedAt") FROM '$$PATH$$/2925.dat';

--
-- Data for Name: Invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Invoices" (id, "invoicerId", "invoiceSerial", "itemName", quantity, rate, amount, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Invoices" (id, "invoicerId", "invoiceSerial", "itemName", quantity, rate, amount, "createdAt", "updatedAt") FROM '$$PATH$$/2927.dat';

--
-- Data for Name: RequestComponents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RequestComponents" (id, "userId", "categoryId", "componentId", "componentName", issue, status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."RequestComponents" (id, "userId", "categoryId", "componentId", "componentName", issue, status, "createdAt", "updatedAt") FROM '$$PATH$$/2933.dat';

--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SequelizeMeta" (name) FROM stdin;
\.
COPY public."SequelizeMeta" (name) FROM '$$PATH$$/2917.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, username, password, "firstName", "lastName", email, "contactNo", role, status, "passwordResetToken", "passwordResetExpires", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Users" (id, username, password, "firstName", "lastName", email, "contactNo", role, status, "passwordResetToken", "passwordResetExpires", "createdAt", "updatedAt") FROM '$$PATH$$/2919.dat';

--
-- Name: Categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categories_id_seq"', 13, true);


--
-- Name: Components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Components_id_seq"', 5, true);


--
-- Name: IncidentUpdates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."IncidentUpdates_id_seq"', 7, true);


--
-- Name: Incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Incidents_id_seq"', 13, true);


--
-- Name: Invoicers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Invoicers_id_seq"', 1, false);


--
-- Name: Invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Invoices_id_seq"', 1, false);


--
-- Name: RequestComponents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RequestComponents_id_seq"', 14, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_id_seq"', 2, true);


--
-- Name: Categories Categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Categories"
    ADD CONSTRAINT "Categories_pkey" PRIMARY KEY (id);


--
-- Name: Components Components_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Components"
    ADD CONSTRAINT "Components_pkey" PRIMARY KEY (id);


--
-- Name: IncidentUpdates IncidentUpdates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IncidentUpdates"
    ADD CONSTRAINT "IncidentUpdates_pkey" PRIMARY KEY (id);


--
-- Name: Incidents Incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Incidents"
    ADD CONSTRAINT "Incidents_pkey" PRIMARY KEY (id);


--
-- Name: Invoicers Invoicers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoicers"
    ADD CONSTRAINT "Invoicers_pkey" PRIMARY KEY (id);


--
-- Name: Invoices Invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_pkey" PRIMARY KEY (id);


--
-- Name: RequestComponents RequestComponents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestComponents"
    ADD CONSTRAINT "RequestComponents_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Components Components_assignedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Components"
    ADD CONSTRAINT "Components_assignedBy_fkey" FOREIGN KEY ("assignedBy") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Components Components_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Components"
    ADD CONSTRAINT "Components_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Components Components_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Components"
    ADD CONSTRAINT "Components_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Categories"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: IncidentUpdates IncidentUpdates_incidentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IncidentUpdates"
    ADD CONSTRAINT "IncidentUpdates_incidentId_fkey" FOREIGN KEY ("incidentId") REFERENCES public."Incidents"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: IncidentUpdates IncidentUpdates_updateBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IncidentUpdates"
    ADD CONSTRAINT "IncidentUpdates_updateBy_fkey" FOREIGN KEY ("updateBy") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Incidents Incidents_incidentBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Incidents"
    ADD CONSTRAINT "Incidents_incidentBy_fkey" FOREIGN KEY ("incidentBy") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Incidents Incidents_resolvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Incidents"
    ADD CONSTRAINT "Incidents_resolvedBy_fkey" FOREIGN KEY ("resolvedBy") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoices Invoices_invoicerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_invoicerId_fkey" FOREIGN KEY ("invoicerId") REFERENCES public."Invoicers"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RequestComponents RequestComponents_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestComponents"
    ADD CONSTRAINT "RequestComponents_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Categories"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RequestComponents RequestComponents_componentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestComponents"
    ADD CONSTRAINT "RequestComponents_componentId_fkey" FOREIGN KEY ("componentId") REFERENCES public."Components"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RequestComponents RequestComponents_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestComponents"
    ADD CONSTRAINT "RequestComponents_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

